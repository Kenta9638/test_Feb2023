function mode = nc_write_mode()
% NC_WRITE_MODE:  returns integer mnemonic for NC_WRITE
%
% USAGE:  mode = nc_write_mode;
mode = 1;
return


